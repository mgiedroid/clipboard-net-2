from fastapi import APIRouter
from app.services.msgraph_service import get_channel_delta_messages

router = APIRouter()

@router.get("/teams/{team_id}/channels/{channel_id}/delta")
def read_delta(team_id: str, channel_id: str):
    return get_channel_delta_messages(team_id, channel_id)
