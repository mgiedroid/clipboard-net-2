import logging
from app.config import settings
from app.services.msgraph_service import get_channel_delta_messages
from app.services.azure_blob_service import save_messages_to_blob

logger = logging.getLogger(__name__)

def fetch_and_save_messages():
    logger.info("Cron job started: fetching Teams delta messages...")
    for entry in settings.TEAMS_CHANNELS:
        team_id = entry["team_id"]
        channel_id = entry["channel_id"]

        try:
            delta_data = get_channel_delta_messages(team_id, channel_id)
            if delta_data.get("value"):
                blob_name = save_messages_to_blob(team_id, channel_id, delta_data)
                logger.info(f"Saved updates to: {blob_name}")
            else:
                logger.info("No new messages.")
        except Exception as ex:
            logger.error(f"Error processing {team_id}/{channel_id}: {ex}")
