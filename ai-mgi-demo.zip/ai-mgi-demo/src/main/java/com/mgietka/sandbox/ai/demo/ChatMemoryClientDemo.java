package com.mgietka.sandbox.ai.demo;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;


@Component
public class ChatMemoryClientDemo implements CommandLineRunner {

    //private ChatClient chatClient;
    @Autowired
    private ChatClient.Builder builder;

    @Autowired
    private ChatMemory chatMemory;

    @Order(3)
    @Override
    public void run(String... args) throws Exception {

        System.out.println("====== Executing " + this.getClass().getSimpleName());

//        ChatClient chatClient = builder
//                .defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build())
//                .build();
//
//        String response = chatClient
//                .prompt("""
//                Tell me what is Wroclaw in one sentence
//                """)
//                .call()
//                .content();
//        System.out.println(response);
//
//        Population populationResponse = chatClient
//                .prompt("""
//                How many people live there?
//                """)
//                .call()
//                .entity(Population.class);
//        if (populationResponse!=null) {
//            System.out.println(populationResponse.cityName + " has about " + populationResponse.population);
//        }
    }

    record Population(String cityName, int population) {}

}
