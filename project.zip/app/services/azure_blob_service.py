import json
from datetime import datetime
from azure.storage.blob import BlobServiceClient
from app.config import settings

def get_blob_client():
    return BlobServiceClient.from_connection_string(settings.AZURE_STORAGE_CONNECTION_STRING)

def save_messages_to_blob(team_id: str, channel_id: str, messages: dict):
    blob_service = get_blob_client()
    container = blob_service.get_container_client(settings.AZURE_STORAGE_CONTAINER)

    try:
        container.create_container()
    except Exception:
        pass

    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    blob_name = f"{team_id}/{channel_id}/messages_{timestamp}.json"
    container.upload_blob(name=blob_name, data=json.dumps(messages, indent=2), overwrite=True)
    return blob_name
