import json
from pydantic import BaseSettings

class Settings(BaseSettings):
    TENANT_ID: str
    CLIENT_ID: str
    CLIENT_SECRET: str

    AZURE_STORAGE_CONNECTION_STRING: str
    AZURE_STORAGE_CONTAINER: str = "teams-messages"

    TEAMS_CHANNELS: list[dict] = []

    class Config:
        env_file = ".env"

settings = Settings()
