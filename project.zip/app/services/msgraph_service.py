import requests
import msal
from app.config import settings
from app.services.delta_links_service import get_delta_link, save_delta_link

GRAPH_SCOPE = ["https://graph.microsoft.com/.default"]
GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"

def get_access_token():
    app = msal.ConfidentialClientApplication(
        client_id=settings.CLIENT_ID,
        client_credential=settings.CLIENT_SECRET,
        authority=f"https://login.microsoftonline.com/{settings.TENANT_ID}"
    )
    token = app.acquire_token_for_client(scopes=GRAPH_SCOPE)
    if "access_token" not in token:
        raise Exception(f"Token error: {token}")
    return token["access_token"]

def get_channel_delta_messages(team_id: str, channel_id: str):
    token = get_access_token()
    delta_url = get_delta_link(team_id, channel_id)

    if delta_url:
        url = delta_url
    else:
        url = f"{GRAPH_BASE_URL}/teams/{team_id}/channels/{channel_id}/messages/delta"

    headers = {"Authorization": f"Bearer {token}"}
    resp = requests.get(url, headers=headers)
    data = resp.json()

    delta_link = data.get("@odata.deltaLink")
    next_link = data.get("@odata.nextLink")

    while next_link:
        resp = requests.get(next_link, headers=headers)
        chunk = resp.json()
        if "value" in chunk:
            data["value"].extend(chunk["value"])
        next_link = chunk.get("@odata.nextLink")
        if chunk.get("@odata.deltaLink"):
            delta_link = chunk["@odata.deltaLink"]

    if delta_link:
        save_delta_link(team_id, channel_id, delta_link)

    return data
