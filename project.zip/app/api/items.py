from fastapi import APIRouter
from app.models.item import Item
from app.services import items_service

router = APIRouter()

@router.get("/")
def list_items():
    return items_service.list_items()

@router.get("/{item_id}")
def get_item(item_id: int):
    return items_service.get_item(item_id)

@router.post("/", status_code=201)
def create_item(item: Item):
    item_id, created_item = items_service.create_item(item)
    return {"id": item_id, "item": created_item}

@router.put("/{item_id}")
def update_item(item_id: int, item: Item):
    return items_service.update_item(item_id, item)

@router.delete("/{item_id}", status_code=204)
def delete_item(item_id: int):
    items_service.delete_item(item_id)
