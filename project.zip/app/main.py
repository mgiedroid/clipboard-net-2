from fastapi import FastAPI
from apscheduler.schedulers.background import BackgroundScheduler
from app.api.items import router as items_router
from app.api.teams import router as teams_router
from app.scheduler.jobs import fetch_and_save_messages

app = FastAPI()
app.include_router(items_router, prefix="/items", tags=["items"])
app.include_router(teams_router, tags=["teams"])

scheduler = BackgroundScheduler()

@app.on_event("startup")
def start_scheduler():
    scheduler.add_job(fetch_and_save_messages, trigger="cron", minute="*/10", id="fetch_messages")
    scheduler.start()

@app.on_event("shutdown")
def shutdown_scheduler():
    scheduler.shutdown()
