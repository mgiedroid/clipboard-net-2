package com.mgietka.sandbox.ai.demo;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ChatWithToolClientDemo implements CommandLineRunner {

    private ChatClient.Builder builder;

    @Override
    public void run(String... args) throws Exception {
        System.out.println("====== Executing " + this.getClass().getSimpleName());

        ChatClient chatClient = builder.build();

        String missingDataResponse = chatClient
                .prompt("""
                Show me all DEV team members in Wroclaw from MyCompany
                """)
                .advisors(new SimpleLoggerAdvisor())
                .call()
                .content();
        System.out.println("Answer: " + missingDataResponse);

        String response = chatClient
                .prompt("""
                Show me all DEV team members in Wroclaw from MyCompany
                """)
                .advisors(new SimpleLoggerAdvisor())
                .tools(new TeamMembersAiTool()) // HERE iS THE TOOL!
                .call()
                .content();
        System.out.println("Answer: " + response);

        ChatResponse chatResponse = chatClient
                .prompt("""
                Which location of MyCompany has more devs?
                """)
                .tools(new TeamMembersAiTool())
                .call()
                .chatResponse();
        if (chatResponse != null) {
            System.out.println("Answer: " + chatResponse.getResult().getOutput().getText());

        }
    }

    static class TeamMembersAiTool {
        @Tool(name = "Team-Members-Wro", description = "Provides list of MyCompany DEV team members in Wroclaw")
        public List<String> getTeamMembersWro() {
            System.out.println("*** TeamMembersAiTool for Wro called");
            return List.of("Marcin", "Michal", "Robert");
        }

        @Tool(name = "Team-Members-Zrh", description = "Provides list of MyCompany DEV team members in Warsaw")
        public List<String> getTeamMembersWaw() {
            System.out.println("*** TeamMembersAiTool for Waw called");
            return List.of("Andrzej", "Zbigniew");
        }

    }

    public ChatWithToolClientDemo(ChatClient.Builder builder) {
        this.builder = builder;
    }

}
