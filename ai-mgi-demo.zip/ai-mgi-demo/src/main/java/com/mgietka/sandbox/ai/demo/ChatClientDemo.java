package com.mgietka.sandbox.ai.demo;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
public class ChatClientDemo implements CommandLineRunner {

    //private ChatClient chatClient;
    @Autowired
    private ChatClient.Builder builder;

    @Order(2)
    @Override
    public void run(String... args) throws Exception {
        System.out.println("====== Executing " + this.getClass().getSimpleName());

//        ChatClient chatClient = builder.build();
//
//        String response = chatClient
//                .prompt("""
//                Tell me what is Wroclaw in one sentence
//                """)
//                .system("""
//                Your response should include only some statistical data about area, population etc.
//                """)
//                .call()
//                .content();
//
//        System.out.println(response);
//
    }

}
