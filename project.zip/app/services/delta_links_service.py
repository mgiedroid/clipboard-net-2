import json
from pathlib import Path

DELTA_FILE = Path(__file__).parent.parent / "storage" / "delta_links.json"

def load_delta_links():
    if not DELTA_FILE.exists():
        return {}
    return json.loads(DELTA_FILE.read_text())

def save_delta_link(team_id: str, channel_id: str, delta_link: str):
    data = load_delta_links()
    key = f"{team_id}:{channel_id}"
    data[key] = delta_link
    DELTA_FILE.write_text(json.dumps(data, indent=2))

def get_delta_link(team_id: str, channel_id: str):
    data = load_delta_links()
    return data.get(f"{team_id}:{channel_id}")
