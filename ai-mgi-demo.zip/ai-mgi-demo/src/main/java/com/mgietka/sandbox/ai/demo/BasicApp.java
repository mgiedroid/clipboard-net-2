package com.mgietka.sandbox.ai.demo;

import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.ai.openai.api.OpenAiApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;

/**
 * This example uses OpenAi API directly
 */
@SpringBootApplication
class BasicApp implements CommandLineRunner {

    @Value("${spring.ai.openai.api-key}")
    private String API_KEY;

    @Order(1)
	@Override
	public void run(String... args) {
        System.out.println("====== Executing " + this.getClass().getSimpleName());

//        OpenAiApi openAiApi = OpenAiApi.builder()
//                .apiKey(API_KEY)
//                .build();
//
//        OpenAiChatOptions openAiChatOptions = OpenAiChatOptions.builder()
//                .model(OpenAiApi.ChatModel.GPT_4_1_MINI)
//                .build();
//
//        ChatModel chatModel = OpenAiChatModel
//                .builder()
//                .openAiApi(openAiApi)
//                .defaultOptions(openAiChatOptions)
//                .build();
//
//        String response = chatModel.call("""
//                Tell me in few words what is Wroclaw
//                """);
//
//		System.out.println(response);
	}

	
	public static void main(String[] args) {
        SpringApplication.run(BasicApp.class, args);
    }

}