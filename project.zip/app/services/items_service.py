from fastapi import HTTPException
from app.storage.memory import items_db
from app.models.item import Item

def list_items():
    return items_db

def get_item(item_id: int):
    if item_id not in items_db:
        raise HTTPException(status_code=404, detail="Item not found")
    return items_db[item_id]

def create_item(item: Item):
    item_id = len(items_db) + 1
    items_db[item_id] = item
    return item_id, item

def update_item(item_id: int, item: Item):
    if item_id not in items_db:
        raise HTTPException(status_code=404, detail="Item not found")
    items_db[item_id] = item
    return item

def delete_item(item_id: int):
    if item_id not in items_db:
        raise HTTPException(status_code=404, detail="Item not found")
    del items_db[item_id]
